package com.example.recivil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecivilApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecivilApplication.class, args);
	}

}
