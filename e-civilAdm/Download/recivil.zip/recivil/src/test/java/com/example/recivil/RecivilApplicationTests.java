package com.example.recivil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecivilApplicationTests {

	@Test
	void contextLoads() {
	}

}
